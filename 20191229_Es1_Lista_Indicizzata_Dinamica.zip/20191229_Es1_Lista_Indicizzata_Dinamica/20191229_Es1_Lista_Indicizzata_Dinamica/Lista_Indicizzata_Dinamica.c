//Author: Filippo Venturini
//Date(DeadLine): 20191229
//Notes: Esercizio 1 | .c per le funzioni della lista
#include "Lista_Indicizzata_Dinamica.h"

//Inizializza tutti i valori della lista a NULL e l'indice a -1
void InizializzaLista(Lista* ptrLista) {
	ptrLista->size = 1; //Setta la dimensione iniziale della lista
	ptrLista->first = (ElementLista*)malloc(ptrLista->size * sizeof(ElementLista));
	ptrLista->iUltimo = EMPTY;
	if (ptrLista == NULL) {
		printf("\n\tMemoria insufficente!\n");
	}
	return;
}
//Effettua la free sul vettore dinamico
void LiberaLista(Lista* ptrLista) {
	free(ptrLista ->first);
	return;
}
//Verifica che la lista sia piena controllando l'indice dell'ultimo elemento
bool ListaPiena(Lista l) {
	if (l.iUltimo == (l.size-1))
		return true;
	return false;
}

//Verifica se la lista � vuota
bool ListaVuota(Lista l) {
	if (l.iUltimo == EMPTY)
		return true;
	return false;
}

void InserisciTesta(Lista* ptrLista, ElementLista value) {
	if (ListaPiena(*ptrLista)) { //Se la lista � piena
		ptrLista->size *= 2; //Raddoppia la dimensione
		ptrLista->first = (ElementLista*)realloc(ptrLista->first, ptrLista->size * sizeof(ElementLista)); //Riassegna al ptr al primo elemento la nuova locazione
		if (ptrLista->first == NULL) {
			printf("\n\tMemoria insufficiente!\n"); //In caso di errore nella malloc
			return;
		}
	}

	if (ListaVuota(*ptrLista)) { //Se la lista � vuota
		*(ptrLista->first) = value; //Viene aggiunto come primo elemento
		ptrLista->iUltimo = 0; //E settato a 0 la posizione dell'ultimo
		return;
	}

	for (int i = ptrLista->iUltimo; i >= 0; i--) { //Ciclo che fa scorrere tutti gli elementi partendo dall'ultimo
		ptrLista->first[i + 1] = ptrLista->first[i]; //Vengono spostati in avanti
		if (i == 0) {
			ptrLista->first[i] = value; //Al primo posto viene inserito il nuovo elemento
		}
	}
	ptrLista->iUltimo++; //Aggiorna l'indice dell'ultimo elemento
	return;
}

void InserisciCoda(Lista* ptrLista, ElementLista value) {
	if (ListaPiena(*ptrLista)) { //Se la lista � piena
		ptrLista->size *= 2; //Raddoppia la dimensione
		ptrLista->first = (ElementLista*)realloc(ptrLista->first, ptrLista->size * sizeof(ElementLista)); //Riassegna al ptr al primo elemento la nuova locazione
		if (ptrLista->first == NULL) {
			printf("\n\tMemoria insufficiente!\n"); //In caso di errore nella malloc
			return;
		}
	}

	if (ListaVuota(*ptrLista)) { //Se la lista � vuota
		ptrLista->first[0] = value; //Viene aggiunto come primo elemento
		ptrLista->iUltimo = 0; //E settato a 0 la posizione dell'ultimo
		return;
	}

	ptrLista->first[(ptrLista->iUltimo) + 1] = value; //Aggiunge in coda alla lista l'elemento
	ptrLista->iUltimo++; //Aggiorna la posizione dell'ultimo
	return;
}

void InserisciDopoElemento(Lista* ptrLista, ElementLista e, ElementLista daInserire) {
	if (ListaPiena(*ptrLista)) { //Se la lista � piena
		ptrLista->size *= 2; //Raddoppia la dimensione
		ptrLista->first = (ElementLista*)realloc(ptrLista->first, ptrLista->size * sizeof(ElementLista)); //Riassegna al ptr al primo elemento la nuova locazione
		if (ptrLista->first == NULL) {
			printf("\n\tMemoria insufficiente!\n"); //In caso di errore nella malloc
			return;
		}
	}

	if (ListaVuota(*ptrLista)) { //Se la lista � vuota
		ptrLista->first[0] = e; //Viene aggiunto come primo elemento
		ptrLista->iUltimo = 0; //E settato a 0 la posizione dell'ultimo
		return;
	}

	for (int i = 0; i <= ptrLista->iUltimo; i++) { //Scorre tutti gli elementi fino a trovare quello desiderato
		if (e == ptrLista->first[i]) {
			for (int j = ptrLista->iUltimo; j > i; j--) {
				ptrLista->first[j + 1] = ptrLista->first[j]; //Sposta tutti gli elementi successivi avanti di una posizione
			}
			ptrLista->first[i + 1] = daInserire; //Inserisce l'elemento da inserire nella posizione vuota appena creata
			break;
		}
	}
	ptrLista->iUltimo++; //Incrementa l'indice dell'ultimo elemento
	return;
}

void CancellaTesta(Lista* ptrLista) {
	if (ListaVuota(*ptrLista)) {
		printf("\n\tLa lista e' vuota!\n");//Se � vuota messaggio di errore
		return;
	}

	if ((ptrLista->iUltimo == (ptrLista->size - 1)) / 2 && ptrLista->size != 1) { //Se ne sono stati cancellati la met� restringe il vettore
		ptrLista->size /= 2; //Dimezza la dimensione
		ptrLista->first = (ElementLista*)realloc(ptrLista->first, ptrLista->size * sizeof(ElementLista)); //Riassegna al ptr al primo elemento la nuova locazione
		if (ptrLista->first == NULL) {
			printf("\n\tMemoria insufficiente!\n"); //In caso di errore nella malloc
			return;
		}
	}

	for (int i = 0; i < ptrLista->iUltimo; i++) {
		ptrLista->first[i] = ptrLista->first[i + 1]; //Sovrascrive gli elementi spostandoli indietro
	}
	ptrLista->iUltimo--; //Decrementa l'indice
	return;
}

void CancellaCoda(Lista* ptrLista) {
	if (ListaVuota(*ptrLista)) {
		printf("\n\tLa lista e' vuota!\n");//Se � vuota messaggio di errore
		return;
	}
	if (ptrLista->iUltimo == (ptrLista->size - 1) / 2 && ptrLista->size != 1) { //Se ne sono stati cancellati la met� restringe il vettore
		ptrLista->size /= 2; //Dimezza la dimensione
		ptrLista->first = (ElementLista*)realloc(ptrLista->first, ptrLista->size * sizeof(ElementLista)); //Riassegna al ptr al primo elemento la nuova locazione
		if (ptrLista->first == NULL) {
			printf("\n\tMemoria insufficiente!\n"); //In caso di errore nella malloc
			return;
		}
	}
	ptrLista->first[ptrLista->iUltimo] = NULL; //Assegna NULL all'ultimo elemento
	ptrLista->iUltimo--;//Decrementa l'indice
	return;
}

void CancellaOccorrenza(Lista* ptrLista, ElementLista e) {
	if (ListaVuota(*ptrLista)) {
		printf("\n\tLa lista e' vuota!\n");//Se � vuota messaggio di errore
		return;
	}
	if (ptrLista->iUltimo == (ptrLista->size - 1) / 2 && ptrLista->size != 1) { //Se ne sono stati cancellati la met� restringe il vettore
		ptrLista->size /= 2; //Dimezza la dimensione
		ptrLista->first = (ElementLista*)realloc(ptrLista->first, ptrLista->size * sizeof(ElementLista)); //Riassegna al ptr al primo elemento la nuova locazione
		if (ptrLista->first == NULL) {
			printf("\n\tMemoria insufficiente!\n"); //In caso di errore nella malloc
			return;
		}
	}
	for (int i = 0; i <= ptrLista->iUltimo; i++) { //Scorre tutti gli elementi
		if (e == ptrLista->first[i]) { //Quando trova l'elemento giusto
			for (int j = i; j < ptrLista->iUltimo; j++) {
				ptrLista->first[j] = ptrLista->first[j + 1]; //Sposta indietro tutti i successivi sovrascrivendoli
			}
			ptrLista->iUltimo--; //Decrementa l'indice
			return; //Esce dalla funzione
		}
	}
	printf("\n\tL'occorrenza non e' presente.\n"); //Messaggio di errore
	return;
}

void StampaLista(Lista l) {
	if (ListaVuota(l)) { //In caso di lista vuota non viene stampato nulla
		return;
	}
	for (int i = 0; i <= l.iUltimo; i++) {
		printf("%d", *(l.first + i));
		if (i == l.iUltimo)
			break;
		printf(" --> ");
	}
	return;
}