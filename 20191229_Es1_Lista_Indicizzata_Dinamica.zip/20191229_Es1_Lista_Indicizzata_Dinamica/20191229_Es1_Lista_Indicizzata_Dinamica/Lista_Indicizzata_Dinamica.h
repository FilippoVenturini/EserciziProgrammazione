//Author: Filippo Venturini
//Date(DeadLine): 20191229
//Notes: Esercizio 1 | Header per la lista
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#define EMPTY -1 //Lista vuota

typedef int ElementLista;

typedef struct {
	ElementLista* first;
	int iUltimo; //Mantiene l'indice dell'ultimo elemento
	int size; //Dimensione del vettore dinamico
}Lista;

void InizializzaLista(Lista*);
void LiberaLista(Lista*);
bool ListaPiena(Lista);
bool ListaVuota(Lista);
void InserisciTesta(Lista*, ElementLista);
void InserisciCoda(Lista*, ElementLista);
void InserisciDopoElemento(Lista*, ElementLista, ElementLista daInserire);
void CancellaTesta(Lista*);
void CancellaCoda(Lista*);
void CancellaOccorrenza(Lista*, ElementLista);
void StampaLista(Lista l);