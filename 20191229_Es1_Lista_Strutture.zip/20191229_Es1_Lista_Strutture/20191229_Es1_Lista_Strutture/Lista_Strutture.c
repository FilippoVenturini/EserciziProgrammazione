//Author: Filippo Venturini
//Date(DeadLine): 20191229
//Notes: Esercizio 1 | .c per le funzioni della lista
#include "Lista_Strutture.h"

//Inizializza tutti i valori della lista a NULL e l'indice a -1
void InizializzaLista(Lista* ptrLista) {
	*ptrLista = NULL; //Inizializza il ptr al primo elemento a NULL
	return;
}

//Verifica se la lista � vuota
bool ListaVuota(Lista l) {
	if (l == NULL)
		return true;
	return false;
}

void InserisciTesta(Lista* ptrLista, ElementLista value) {
	if (ListaVuota(*ptrLista)) { //Se la lista � vuota
		*ptrLista = (Lista) malloc(sizeof(NodoLista)); //Viene assegnato al puntatore alla testa lo spazio necessario ad un nodo
		if (*ptrLista == NULL) {
			printf("\n\tMemoria insufficente!\n"); //Controllo per la malloc
			return;
		}
		(*ptrLista)->value = value; //Assegna il valore all'attributo del NodoLista
		(*ptrLista)->next = NULL; //Assegna NULL al puntatore all'elemento successivo
		return;
	}

	NodoLista* ptrTmp = (NodoLista*)malloc(sizeof(NodoLista)); //Assegna temporaneamente la zona di memoria ad un ptr
	if (ptrTmp == NULL) {
		printf("\n\tMemoria insufficente!\n"); //Controllo per la malloc
		return;
	}
	ptrTmp->value = value; //Inizializza il nuovo nodo
	ptrTmp->next = (*ptrLista); //Assegna al next del nuovo elemento l'indirizzo della testa
	*ptrLista = ptrTmp; //Assegna al puntatore alla testa il nuovo elemento
	return;
}

void InserisciCoda(Lista* ptrLista, ElementLista value) {
	if (ListaVuota(*ptrLista)) { //Se la lista � vuota
		*ptrLista = (Lista)malloc(sizeof(NodoLista)); //Viene assegnato al puntatore alla testa lo spazio necessario ad un nodo
		if (*ptrLista == NULL) {
			printf("\n\tMemoria insufficente!\n"); //Controllo per la malloc
			return;
		}
		(*ptrLista)->value = value; //Assegna il valore all'attributo del NodoLista
		(*ptrLista)->next = NULL; //Assegna NULL al puntatore all'elemento successivo
		return;
	}

	Lista tmp = *ptrLista; //Puntatore temporaneo al primo elemento
	while (tmp->next != NULL) { //Finch� non arriva all'ultimo
		tmp = tmp->next; //Scorre la lista
	}

	Lista tmp2 = (Lista)malloc(sizeof(NodoLista)); //Alloca lo spazio per il nuovo nodo
	if (tmp2 == NULL) {
		printf("\n\tMemoria insufficente!\n"); //Controllo per la malloc
		return;
	}
	tmp2->next = NULL;
	tmp2->value = value; //Assegna il valore
	tmp->next = tmp2; //Collega il nuovo nodo al precedente
	return;
}

void InserisciDopoElemento(Lista* ptrLista, ElementLista e, ElementLista daInserire) {
	if (ListaVuota(*ptrLista)) { //Se la lista � vuota
		*ptrLista = (Lista)malloc(sizeof(NodoLista)); //Viene assegnato al puntatore alla testa lo spazio necessario ad un nodo
		if (*ptrLista == NULL) {
			printf("\n\tMemoria insufficente!\n"); //Controllo per la malloc
			return;
		}
		(*ptrLista)->value = daInserire; //Assegna il valore all'attributo del NodoLista
		(*ptrLista)->next = NULL; //Assegna NULL al puntatore all'elemento successivo
		return;
	}

	Lista tmp = *ptrLista;//Puntatore temporaneo al primo elemento
	while (tmp->value != e) { //Fino a che non si trova l'elemento desiderato
		tmp = tmp->next; //Scorre avanti
	}

	Lista tmp2 = (Lista)malloc(sizeof(NodoLista)); //Alloca lo spazio per il nuovo nodo
	if (tmp2 == NULL) {
		printf("\n\tMemoria insufficente!\n"); //Controllo per la malloc
		return;
	}
	tmp2->next = tmp->next; //Collega il successivo del nuovo nodo 
	tmp2->value = daInserire; //Assegna il valore

	tmp->next = tmp2;//Collega il nuovo nodo al precedente
	return;
}

void CancellaTesta(Lista* ptrLista) {
	if (ListaVuota(*ptrLista)) {
		printf("\n\tLa lista e' vuota!\n");//Se � vuota messaggio di errore
		return;
	}

	Lista tmpTesta = (*ptrLista)->next;

	free(*ptrLista);
	*ptrLista = tmpTesta;
	return;
}

void CancellaCoda(Lista* ptrLista) {
	if (ListaVuota(*ptrLista)) {
		printf("\n\tLa lista e' vuota!\n");//Se � vuota messaggio di errore
		return;
	}
	
	NodoLista* tmp = *ptrLista;
	NodoLista* tmp1 = (*ptrLista)->next; //Tmp di una posizione avanti
	while (tmp1->next != NULL) { //Scorre fino alla fine
		tmp = tmp->next;
		tmp1 = tmp1->next;
	}

	free(tmp1); //Cancella l'elemento pi� avanti
	tmp->next = NULL; //Setta a NULL il next dell'ultimo
	return;
}

void CancellaOccorrenza(Lista* ptrLista, ElementLista e) {
	if (ListaVuota(*ptrLista)) {
		printf("\n\tLa lista e' vuota!\n");//Se � vuota messaggio di errore
		return;
	}
	if ((*ptrLista)->value == e) { //In caso l'occorrenza sia in testa
		CancellaTesta(ptrLista);
		return;
	}

	NodoLista* tmp = *ptrLista;
	NodoLista* tmp1 = (*ptrLista)->next;//Tmp di una posizione avanti
	while (tmp1->value != e) { //Scorre tutti gli elementi fino a quello desiderato
		tmp = tmp->next;
		tmp1 = tmp1->next;
		if (tmp1 == NULL) {
			printf("\n\tL'occorrenza non e' presente.\n"); //Messaggio di errore
			return;
		}
	}
	tmp->next = tmp1->next; //Aggiorna il collegamento
	free(tmp1); //Cancella l'elemento
	return;
}

void StampaLista(Lista l) {
	while (l != NULL) {
		printf("%d", l->value);
		if (l->next == NULL)
			break;
		printf(" --> ");
		l = l->next; //Scorre la lista
	}
	return;
}

void CancellaLista(Lista* ptrLista) {
	NodoLista* tmp = *ptrLista;
	while (tmp->next != NULL) {
		tmp = tmp->next; //Scorre tmp
		free(*ptrLista); //Cancella l'elemento precedente
		*ptrLista = tmp; //Scorre il ptr al precedente
	}
	free(tmp); //Cancella l'ultimo elemento
	return;
}