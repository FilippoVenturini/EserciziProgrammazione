//Author: Filippo Venturini
//Date(DeadLine): 20191229
//Notes: Esercizio 1 | Header per la lista
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#define MAX 10 //Massimo per gli elementi
#define EMPTY -1 //Lista vuota

typedef int ElementLista; //Definisce il tipo int come il tipo dell'elemento della lista

typedef struct {
	ElementLista value;
	struct NodoLista* next;
} NodoLista; //Un nodo della lista contiene il valore e il puntatore al successivo

typedef NodoLista* Lista; //La lista � il puntatore alla testa

void InizializzaLista(Lista*);
bool ListaVuota(Lista);
void InserisciTesta(Lista*, ElementLista);
void InserisciCoda(Lista*, ElementLista);
void InserisciDopoElemento(Lista*, ElementLista, ElementLista daInserire);
void CancellaTesta(Lista*);
void CancellaCoda(Lista*);
void CancellaOccorrenza(Lista*, ElementLista);
void StampaLista(Lista l);
void CancellaLista(Lista*);
