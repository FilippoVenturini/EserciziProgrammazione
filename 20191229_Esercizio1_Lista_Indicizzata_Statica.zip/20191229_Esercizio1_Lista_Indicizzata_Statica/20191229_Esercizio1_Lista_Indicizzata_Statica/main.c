//Author: Filippo Venturini
//Date(DeadLine): 20191229
//Notes: Esercizio 1 | main
#include "Lista_Indicizzata.h"
int main() {
	Lista l; //Crea una istanza
	InizializzaLista(&l); //Inizializza l'istanza
	ElementLista e = 0;
	ElementLista e1 = 0; //Elemento dopo cui inserire, nella funz. InserisciDopoElemento
	int opzScelta;
	int verificaScanf;
	
	do{	
		do {
			verificaScanf = 0;
			opzScelta = 0;
			printf("\n1) Aggiungere in testa.");
			printf("\n2) Aggiungere in coda.");
			printf("\n3) Aggiungere dopo un elemento.");
			printf("\n4) Cancellare la testa.");
			printf("\n5) Cancellare la coda.");
			printf("\n6) Cancellare occorrenza.");
			printf("\n7) Uscire.");
			printf("\nSelezionare l'opzione desiderata:");
			verificaScanf = scanf("%d", &opzScelta);
			while ((getchar()) != '\n'); //Pulizia del buffer
		} while (verificaScanf != 1 || opzScelta < 1 || opzScelta > 7);

		switch (opzScelta) {
		case 1:		
			do {
				verificaScanf = 0;
				printf("\n\tInserire il valore: ");
				verificaScanf = scanf("%d", &e);
				while ((getchar()) != '\n'); //Pulizia del buffer
			} while (verificaScanf != 1);

			InserisciTesta(&l, e);
			StampaLista(l);
			break;
		case 2:			
			do {
				verificaScanf = 0;
				printf("\n\tInserire il valore: ");
				verificaScanf = scanf("%d", &e);
				while ((getchar()) != '\n'); //Pulizia del buffer
			} while (verificaScanf != 1);

			InserisciCoda(&l, e);
			StampaLista(l);
			break;
		case 3:						
			do {
				verificaScanf = 0;
				printf("\n\tElemento dopo cui inserire: ");
				verificaScanf = scanf("%d", &e1);
				while ((getchar()) != '\n'); //Pulizia del buffer
			} while (verificaScanf != 1);
			
			do {
				verificaScanf = 0;
				printf("\n\tInserire il valore: ");
				verificaScanf = scanf("%d", &e);
				while ((getchar()) != '\n'); //Pulizia del buffer
			} while (verificaScanf != 1);
			InserisciDopoElemento(&l, e1, e);
			StampaLista(l);
			break;
		case 4:
			CancellaTesta(&l);
			StampaLista(l);
			break;
		case 5:
			CancellaCoda(&l);
			StampaLista(l);
			break;
		case 6:
			do {
				verificaScanf = 0;
				printf("\n\tInserire l'occorrenza: ");
				verificaScanf = scanf("%d", &e);
				while ((getchar()) != '\n'); //Pulizia del buffer
			} while (verificaScanf != 1);
			CancellaOccorrenza(&l, e);
			StampaLista(l);
			break;
		case 7:
			break;
		}
	} while (opzScelta != 7);
	
	getchar();
	return 0;
}