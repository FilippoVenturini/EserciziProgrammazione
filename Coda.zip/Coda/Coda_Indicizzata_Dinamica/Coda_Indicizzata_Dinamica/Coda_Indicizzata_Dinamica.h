//Author: Filippo Venturini
//Date(DeadLine):20191229
//Notes: Esercizio 2 | Coda 
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#define EMPTY -1
typedef int ElemCoda;

typedef struct {
	ElemCoda* first;
	int iUltimo; //Mantiene l'indice dell'ultimo elemento
	int size; //Dimensione del vettore dinamico
}Coda;

void InizializzaCoda(Coda*);
void LiberaCoda(Coda*);
bool CodaPiena(Coda);
bool CodaVuota(Coda);
void EnQueque(Coda*, ElemCoda);
void deQueque(Coda*, ElemCoda*);
void First(Coda, ElemCoda*);
void StampaCoda(Coda);