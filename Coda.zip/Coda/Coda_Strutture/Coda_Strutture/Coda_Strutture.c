//Author: Filippo Venturini
//Date(DeadLine):20191229
//Notes: Esercizio 2 | Coda
#include "Coda_Strutture.h"

void InizializzaCoda(Coda* ptrCoda) {
	*ptrCoda = NULL; //Inizializza il ptr al primo elemento a NULL
	return;
}

bool CodaVuota(Coda c) {
	if (c == NULL)
		return true;
	return false;
}

void EnQueque(Coda* ptrCoda, ElemCoda value) {
	if (CodaVuota(*ptrCoda)) { //Se la lista � vuota
		*ptrCoda = (Coda)malloc(sizeof(NodoCoda)); //Viene assegnato al puntatore alla testa lo spazio necessario ad un nodo
		if (*ptrCoda == NULL) {
			printf("\n\tMemoria insufficente!\n"); //Controllo per la malloc
			return;
		}
		(*ptrCoda)->value = value; //Assegna il valore all'attributo del NodoLista
		(*ptrCoda)->next = NULL; //Assegna NULL al puntatore all'elemento successivo
		return;
	}

	Coda tmp = *ptrCoda; //Puntatore temporaneo al primo elemento
	while (tmp->next != NULL) { //Finch� non arriva all'ultimo
		tmp = tmp->next; //Scorre la lista
	}

	Coda tmp2 = (Coda)malloc(sizeof(NodoCoda)); //Alloca lo spazio per il nuovo nodo
	if (tmp2 == NULL) {
		printf("\n\tMemoria insufficente!\n"); //Controllo per la malloc
		return;
	}
	tmp2->next = NULL;
	tmp2->value = value; //Assegna il valore
	tmp->next = tmp2; //Collega il nuovo nodo al precedente
	return;
}

void deQueque(Coda* ptrCoda, ElemCoda* ptrElem) {
	if (CodaVuota(*ptrCoda)) {
		printf("\n\tLa coda e' vuota!\n");//Se � vuota messaggio di errore
		return;
	}

	*ptrElem = (*ptrCoda)->value; //Memorizza il valore e lo restituisce

	Coda tmpTesta = (*ptrCoda)->next;
	free(*ptrCoda);
	*ptrCoda = tmpTesta;
	return;
}

void First(Coda c, ElemCoda* ptrElem) {
	if (CodaVuota(c)) {
		printf("\n\tLa coda e' vuota!\n");//Se � vuota messaggio di errore
		*ptrElem = NULL;
		return;
	}

	*ptrElem = c->value; //Memorizza il valore e lo restituisce
	return;
}

void StampaCoda(Coda c) {
	while (c != NULL) {
		printf("%d", c->value);
		if (c->next == NULL)
			break;
		printf(" --> ");
		c = c->next; //Scorre la lista
	}
	return;
}

void LiberaCoda(Coda* ptrCoda) {
	NodoCoda* tmp = *ptrCoda;
	while (tmp->next != NULL) {
		tmp = tmp->next; //Scorre tmp
		free(*ptrCoda); //Cancella l'elemento precedente
		*ptrCoda = tmp; //Scorre il ptr al precedente
	}
	free(tmp); //Cancella l'ultimo elemento
	return;
}