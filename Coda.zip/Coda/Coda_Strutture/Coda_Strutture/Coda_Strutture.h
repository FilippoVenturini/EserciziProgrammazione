//Author: Filippo Venturini
//Date(DeadLine):20191229
//Notes: Esercizio 2 | Coda |Header
#include <stdbool.h>
#include <stdlib.h>
#include <stdio.h>

typedef int ElemCoda;

typedef struct {
	ElemCoda value;
	struct NodoCoda* next;
}NodoCoda;

typedef NodoCoda* Coda;

void InizializzaCoda(Coda*);
void LiberaCoda(Coda*);
bool CodaVuota(Coda);
void EnQueque(Coda*, ElemCoda);
void deQueque(Coda*, ElemCoda*);
void First(Coda, ElemCoda*);
void StampaCoda(Coda);