//Author: Filippo Venturini
//Date(DeadLine):20191229
//Notes: Esercizio 2 | Coda
#include "Coda_Indicizzata_Dinamica.h"

//Inizializza tutti i valori della coda a NULL e l'indice a -1
void InizializzaCoda(Coda* ptrCoda) {
	ptrCoda->size = 1; //Setta la dimensione iniziale della lista
	ptrCoda->first = (ElemCoda*)malloc(ptrCoda->size * sizeof(ElemCoda));
	ptrCoda->iUltimo = EMPTY;
	if (ptrCoda == NULL) {
		printf("\n\tMemoria insufficente!\n");
	}
	return;
}

//Effettua la free sul vettore dinamico
void LiberaCoda(Coda* ptrCoda) {
	free(ptrCoda->first);
	return;
}

//Verifica se la coda � vuota
bool CodaVuota(Coda c) {
	if (c.iUltimo == EMPTY)
		return true;
	return false;
}

//Verifica che la lista sia piena controllando l'indice dell'ultimo elemento
bool CodaPiena(Coda c) {
	if (c.iUltimo == (c.size - 1))
		return true;
	return false;
}

void EnQueque(Coda* ptrCoda, ElemCoda value) {
	if (CodaPiena(*ptrCoda)) { //Se la coda � piena
		ptrCoda->size *= 2; //Raddoppia la dimensione
		ptrCoda->first = (ElemCoda*)realloc(ptrCoda->first, ptrCoda->size * sizeof(ElemCoda)); //Riassegna al ptr al primo elemento la nuova locazione
		if (ptrCoda->first == NULL) {
			printf("\n\tMemoria insufficiente!\n"); //In caso di errore nella malloc
			return;
		}
	}

	if (CodaVuota(*ptrCoda)) { //Se la coda � vuota
		ptrCoda->first[0] = value; //Viene aggiunto come primo elemento
		ptrCoda->iUltimo = 0; //E settato a 0 la posizione dell'ultimo
		return;
	}

	ptrCoda->first[(ptrCoda->iUltimo) + 1] = value; //Aggiunge in coda l'elemento
	ptrCoda->iUltimo++; //Aggiorna la posizione dell'ultimo
	return;
}

void deQueque(Coda* ptrCoda, ElemCoda* ptrValue) {
	if (CodaVuota(*ptrCoda)) {
		printf("\n\tLa coda e' vuota!\n");//Se � vuota messaggio di errore
		return;
	}

	if ((ptrCoda->iUltimo == (ptrCoda->size - 1)) / 2 && ptrCoda->size != 1) { //Se ne sono stati cancellati la met� restringe il vettore
		ptrCoda->size /= 2; //Dimezza la dimensione
		ptrCoda->first = (ElemCoda*)realloc(ptrCoda->first, ptrCoda->size * sizeof(ElemCoda)); //Riassegna al ptr al primo elemento la nuova locazione
		if (ptrCoda->first == NULL) {
			printf("\n\tMemoria insufficiente!\n"); //In caso di errore nella malloc
			return;
		}
	}
	*ptrValue = ptrCoda->first[0]; //Memorizza il valore da rimuovere e lo restituisce
	for (int i = 0; i < ptrCoda->iUltimo; i++) {
		ptrCoda->first[i] = ptrCoda->first[i + 1]; //Sovrascrive gli elementi spostandoli indietro
	}
	ptrCoda->iUltimo--; //Decrementa l'indice
	return;
}

void First(Coda c, ElemCoda* ptrValue) {
	if (CodaVuota(c)) {
		printf("\n\tLa coda e' vuota!\n");//Se � vuota messaggio di errore
		*ptrValue = NULL; //Restituisce null
		return;
	}
	*ptrValue = c.first[0]; //Memorizza il valore e lo restituisce
}
void StampaCoda(Coda c) {
	if (CodaVuota(c)) { //In caso di coda vuota non viene stampato nulla
		return;
	}
	for (int i = 0; i <= c.iUltimo; i++) {
		printf("%d", *(c.first + i));
		if (i == c.iUltimo)
			break;
		printf(" --> ");
	}
	return;
}