//Author: Filippo Venturini
//Date(DeadLine):20191229
//Notes: Esercizio 2 | Coda 
#include "Coda_Indicizzata_Statica.h"
//Inizializza tutti i valori della coda a NULL e l'indice a -1
void InizializzaCoda(Coda* ptrCoda) {
	ptrCoda->iUltimo = EMPTY;
	for (int i = 0; i < MAX; i++) { //Inizializza il vettore
		ptrCoda->coda[i] = NULL;
	}
	return;
}
//Verifica se la coda � vuota
bool CodaVuota(Coda c) {
	if (c.iUltimo == EMPTY)
		return true;
	return false;
}
//Verifica che la coda sia piena controllando l'indice dell'ultimo elemento
bool CodaPiena(Coda c) {
	if (c.iUltimo == MAX - 1)
		return true;
	return false;
}
void EnQueque(Coda* ptrCoda, ElemCoda value) {
	if (CodaPiena(*ptrCoda)) {
		printf("\n\tLa coda e' piena!\n"); //Se � piena messaggio di errore
		return;
	}

	if (CodaVuota(*ptrCoda)) { //Se la coda � vuota
		ptrCoda->coda[0] = value; //Viene aggiunto come primo elemento
		ptrCoda->iUltimo = 0; //E settato a 0 la posizione dell'ultimo
		return;
	}

	ptrCoda->coda[(ptrCoda->iUltimo) + 1] = value; //Aggiunge in coda l'elemento
	ptrCoda->iUltimo++; //Aggiorna la posizione dell'ultimo
	return;
}
void deQueque(Coda* ptrCoda, ElemCoda* ptrValue) {
	if (CodaVuota(*ptrCoda)) {
		printf("\n\tLa coda e' vuota!\n");//Se � vuota messaggio di errore
		return;
	}

	*ptrValue = ptrCoda->coda[0]; //Memorizza l'elemento da rimuovere
	for (int i = 0; i < ptrCoda->iUltimo; i++) {
		ptrCoda->coda[i] = ptrCoda->coda[i + 1]; //Sovrascrive gli elementi spostandoli indietro
	}
	ptrCoda->iUltimo--; //Decrementa l'indice
	return;
}
void First(Coda c, ElemCoda*ptrValue) {
	if (CodaVuota(c)) {
		printf("\n\tLa coda e' vuota!\n");//Se � vuota messaggio di errore
		*ptrValue = NULL;
		return;
	}
	*ptrValue = c.coda[0]; //Restituisce la testa
	return;
}

void StampaCoda(Coda c) {
	for (int i = 0; i <= c.iUltimo; i++) {
		printf("%d", c.coda[i]);
		if (i == c.iUltimo)
			break;
		printf(" --> ");
	}
	return;
}