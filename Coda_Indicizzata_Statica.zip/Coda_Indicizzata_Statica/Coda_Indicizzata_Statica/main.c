//Author: Filippo Venturini
//Date(DeadLine):20191229
//Notes: Esercizio 2 | Coda | Main
#include "Coda_Indicizzata_Statica.h"
int main() {
	Coda c; //Crea una istanza
	InizializzaCoda(&c); //Inizializza l'istanza
	ElemCoda e = 0;
	int opzScelta;
	int verificaScanf;
	do {
		do {
			verificaScanf = 0;
			opzScelta = 0;
			printf("\n1) EnQueque(Inserire).");
			printf("\n2) deQueque(Rimuovere).");
			printf("\n3) First(Visualizzare il primo elemento).");
			printf("\n4) Uscire.");
			printf("\nSelezionare l'opzione desiderata:");
			verificaScanf = scanf("%d", &opzScelta);
			while ((getchar()) != '\n'); //Pulizia del buffer
		} while (verificaScanf != 1 || opzScelta < 1 || opzScelta > 4);
		switch (opzScelta) {
		case 1:
			do {
				verificaScanf = 0;
				printf("\n\tInserire il valore: ");
				verificaScanf = scanf("%d", &e);
				while ((getchar()) != '\n'); //Pulizia del buffer
			} while (verificaScanf != 1);
			EnQueque(&c, e);
			StampaCoda(c);
			break;
		case 2:
			deQueque(&c, &e);
			StampaCoda(c);
			break;
		case 3:
			First(c, &e);
			if (e != NULL) {
				printf("\n\tIl primo elemento e': %d\n\n", e);
			}		
			StampaCoda(c);
			break;
		case 4:
			break;
		}
	} while (opzScelta != 4);
	getchar();
	return 0;
}