//Author: Filippo Venturini
//Date(DeadLine): 20191229
//Notes: Esercizio 1 | .c per le funzioni della lista
#include "Lista_Indicizzata.h"

//Inizializza tutti i valori della lista a NULL e l'indice a -1
void InizializzaLista(Lista* ptrLista) {
	ptrLista ->iUltimo = EMPTY;
	for (int i = 0; i < MAX; i++) {
		ptrLista->list[i] = NULL;
	}
	return;
}

//Verifica che la lista sia piena controllando l'indice dell'ultimo elemento
bool ListaPiena(Lista l) {
	if (l.iUltimo == MAX-1) 
		return true;
	return false;
}

//Verifica se la lista � vuota
bool ListaVuota(Lista l){
	if (l.iUltimo == EMPTY)
		return true;
	return false;
}

void InserisciTesta(Lista* ptrLista, ElementLista value) {
	if (ListaPiena(*ptrLista)) {
		printf("\n\tLa lista e' piena!\n"); //Se � piena messaggio di errore
		return;
	}

	if (ListaVuota(*ptrLista)) { //Se la lista � vuota
		ptrLista->list[0] = value; //Viene aggiunto come primo elemento
		ptrLista->iUltimo = 0; //E settato a 0 la posizione dell'ultimo
		return;
	}

	for (int i = ptrLista->iUltimo; i >= 0; i--) { //Ciclo che fa scorrere tutti gli elementi partendo dall'ultimo
		ptrLista->list[i + 1] = ptrLista->list[i]; //Vengono spostati in avanti
		if (i == 0) {
			ptrLista->list[i] = value; //Al primo posto viene inserito il nuovo elemento
		}
	}
	ptrLista->iUltimo++; //Aggiorna l'indice dell'ultimo elemento
	return;
}

void InserisciCoda(Lista* ptrLista, ElementLista value) {
	if (ListaPiena(*ptrLista)) {
		printf("\n\tLa lista e' piena!\n"); //Se � piena messaggio di errore
		return;
	}

	if (ListaVuota(*ptrLista)) { //Se la lista � vuota
		ptrLista->list[0] = value; //Viene aggiunto come primo elemento
		ptrLista->iUltimo = 0; //E settato a 0 la posizione dell'ultimo
		return;
	}

	ptrLista->list[(ptrLista->iUltimo) + 1] = value; //Aggiunge in coda alla lista l'elemento
	ptrLista->iUltimo++; //Aggiorna la posizione dell'ultimo
	return;
}

void InserisciDopoElemento(Lista* ptrLista, ElementLista e, ElementLista daInserire) {
	if (ListaPiena(*ptrLista)) {
		printf("\n\tLa lista e' piena!\n"); //Se � piena messaggio di errore
		return;
	}

	if (ListaVuota(*ptrLista)) { //Se la lista � vuota
		ptrLista->list[0] = e; //Viene aggiunto come primo elemento
		ptrLista->iUltimo = 0; //E settato a 0 la posizione dell'ultimo
		return;
	}

	for (int i = 0; i <= ptrLista->iUltimo; i++) { //Scorre tutti gli elementi fino a trovare quello desiderato
		if (e == ptrLista->list[i]) {			
			for (int j = ptrLista->iUltimo; j > i; j--) {
				ptrLista->list[j + 1] = ptrLista->list[j]; //Sposta tutti gli elementi successivi avanti di una posizione
			}
			ptrLista->list[i + 1] = daInserire; //Inserisce l'elemento da inserire nella posizione vuota appena creata
			break;
		}
	}
	ptrLista->iUltimo++; //Incrementa l'indice dell'ultimo elemento
	return;
}

void CancellaTesta(Lista* ptrLista) {
	if (ListaVuota(*ptrLista)) {
		printf("\n\tLa lista e' vuota!\n");//Se � vuota messaggio di errore
		return;
	}

	for (int i = 0; i < ptrLista->iUltimo; i++) {
		ptrLista->list[i] = ptrLista->list[i + 1]; //Sovrascrive gli elementi spostandoli indietro
	}
	ptrLista->iUltimo--; //Decrementa l'indice
	return;
}

void CancellaCoda(Lista* ptrLista) {
	if (ListaVuota(*ptrLista)) {
		printf("\n\tLa lista e' vuota!\n");//Se � vuota messaggio di errore
		return;
	}
	ptrLista->list[ptrLista->iUltimo] = NULL; //Assegna NULL all'ultimo elemento
	ptrLista->iUltimo--;//Decrementa l'indice
	return;
}

void CancellaOccorrenza(Lista* ptrLista, ElementLista e) {
	if (ListaVuota(*ptrLista)) {
		printf("\n\tLa lista e' vuota!\n");//Se � vuota messaggio di errore
		return;
	}
	for (int i = 0; i <= ptrLista->iUltimo; i++) { //Scorre tutti gli elementi
		if (e == ptrLista->list[i]) { //Quando trova l'elemento giusto
			for (int j = i; j < ptrLista->iUltimo; j++) {
				ptrLista->list[j] = ptrLista->list[j + 1]; //Sposta indietro tutti i successivi sovrascrivendoli
			}
			ptrLista->iUltimo--; //Decrementa l'indice
			return; //Esce dalla funzione
		}
	}
	printf("\n\tL'occorrenza non e' presente.\n"); //Messaggio di errore
	return;
}

void StampaLista(Lista l) {
	for (int i = 0; i <= l.iUltimo; i++) {
		printf("%d", l.list[i]);
		if (i == l.iUltimo)
			break;
		printf(" --> ");
	}
	return;
}