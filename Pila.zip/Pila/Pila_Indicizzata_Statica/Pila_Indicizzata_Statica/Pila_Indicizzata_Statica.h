//Author: Filippo Venturini
//Date(DeadLine): 20191229
//Notes: Esercizio 2 | Pila| Header
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#define MAX 10 //Massimo per gli elementi
#define EMPTY -1 //Pila vuota

typedef int ElementPila;

typedef struct {
	ElementPila pila[MAX];
	int iUltimo; //Mantiene l'indice dell'ultimo elemento
}Pila;

void InizializzaPila(Pila*);
bool PilaPiena(Pila);
bool PilaVuota(Pila);
void Push(Pila*, ElementPila);
void Pop(Pila*, ElementPila*);
void Top(Pila, ElementPila*);
void StampaPila(Pila);