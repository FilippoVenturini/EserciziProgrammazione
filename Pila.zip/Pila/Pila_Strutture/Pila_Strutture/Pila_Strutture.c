//Author: Filippo Venturini
//Date(DeadLine): 20191229
//Notes: Esercizio 2 | Pila |
#include "Pila_Strutture.h"

//Inizializza tutti i valori della pila a NULL e l'indice a -1
void InizializzaPila(Pila* ptrPila) {
	*ptrPila = NULL; //Inizializza il ptr al primo elemento a NULL
	return;
}

//Verifica se la pila � vuota
bool PilaVuota(Pila p) {
	if (p == NULL)
		return true;
	return false;
}

void LiberaPila(Pila* ptrPila) {
	if (PilaVuota(*ptrPila)) {
		return; //Se la pila � vuota esce
	}
	NodoPila* tmp = *ptrPila;
	while (tmp->next != NULL) {
		tmp = tmp->next; //Scorre tmp
		free(*ptrPila); //Cancella l'elemento precedente
		*ptrPila = tmp; //Scorre il ptr al precedente
	}
	free(tmp); //Cancella l'ultimo elemento
	return;
}

void Push(Pila* ptrPila, ElementPila value) {
	if (PilaVuota(*ptrPila)) { //Se la lista � vuota
		*ptrPila = (Pila)malloc(sizeof(NodoPila)); //Viene assegnato al puntatore alla testa lo spazio necessario ad un nodo
		if (*ptrPila == NULL) {
			printf("\n\tMemoria insufficente!\n"); //Controllo per la malloc
			return;
		}
		(*ptrPila)->value = value; //Assegna il valore all'attributo del NodoLista
		(*ptrPila)->next = NULL; //Assegna NULL al puntatore all'elemento successivo
		return;
	}

	NodoPila* ptrTmp = (NodoPila*)malloc(sizeof(NodoPila)); //Assegna temporaneamente la zona di memoria ad un ptr
	if (ptrTmp == NULL) {
		printf("\n\tMemoria insufficente!\n"); //Controllo per la malloc
		return;
	}
	ptrTmp->value = value; //Inizializza il nuovo nodo
	ptrTmp->next = (*ptrPila); //Assegna al next del nuovo elemento l'indirizzo della testa
	*ptrPila = ptrTmp; //Assegna al puntatore alla testa il nuovo elemento
	return;
}

void Pop(Pila* ptrPila, ElementPila*ptrElem) {
	if (PilaVuota(*ptrPila)) {
		printf("\n\tLa pila e' vuota!\n");//Se � vuota messaggio di errore
		*ptrElem = NULL;
		return;
	}

	*ptrElem = (*ptrPila)->value; //Memorizza il valore e lo restituisce
	Pila tmpTesta = (*ptrPila)->next;

	free(*ptrPila);
	*ptrPila = tmpTesta;
	return;
}

void Top(Pila p, ElementPila* ptrElem) {
	if (PilaVuota(p)) {
		printf("\n\tLa pila e' vuota!\n");//Se � vuota messaggio di errore
		*ptrElem = NULL;
		return;
	}
	*ptrElem = p->value; //Memorizza il valore e lo restituisce
	return;
}
void StampaPila(Pila p) {
	while (p != NULL) {
		printf("%d", p->value);
		if (p->next == NULL)
			break;
		printf(" --> ");
		p = p->next; //Scorre la lista
	}
	return;
}