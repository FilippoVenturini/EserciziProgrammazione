//Author: Filippo Venturini
//Date(DeadLine): 20191229
//Notes: Esercizio 2 | Pila |
#include "Pila_Indicizzata_Dinamica.h"

//Inizializza tutti i valori della pila a NULL e l'indice a -1
void InizializzaPila(Pila* ptrPila) {
	ptrPila->size = 10; //Setta la dimensione iniziale della pila
	ptrPila->first = (ElementPila*)malloc(ptrPila->size * sizeof(ElementPila));
	ptrPila->iUltimo = EMPTY;
	if (ptrPila == NULL) {
		printf("\n\tMemoria insufficente!\n");
	}
	return;
}
//Effettua la free sul vettore dinamico
void LiberaPila(Pila* ptrPila) {
	free(ptrPila->first);
	return;
}
//Verifica che la pila sia piena controllando l'indice dell'ultimo elemento
bool PilaPiena(Pila p) {
	if (p.iUltimo == (p.size - 1))
		return true;
	return false;
}

//Verifica se la pila � vuota
bool PilaVuota(Pila p) {
	if (p.iUltimo == EMPTY)
		return true;
	return false;
}

void Push(Pila* ptrPila, ElementPila value) {
	if (PilaPiena(*ptrPila)) { //Se la pila � piena
		ptrPila->size *= 2; //Raddoppia la dimensione
		ptrPila->first = (ElementPila*)realloc(ptrPila->first, ptrPila->size * sizeof(ElementPila)); //Riassegna al ptr al primo elemento la nuova locazione
		if (ptrPila->first == NULL) {
			printf("\n\tMemoria insufficiente!\n"); //In caso di errore nella malloc
			return;
		}
	}

	if (PilaVuota(*ptrPila)) { //Se la pila � vuota
		ptrPila->first[0] = value; //Viene aggiunto come primo elemento
		ptrPila->iUltimo = 0; //E settato a 0 la posizione dell'ultimo
		return;
	}

	ptrPila->first[(ptrPila->iUltimo) + 1] = value; //Aggiunge alla pila l'elemento
	ptrPila->iUltimo++; //Aggiorna la posizione dell'ultimo
	return;
}

void Pop(Pila* ptrPila, ElementPila* ptrElem) {
	if (PilaVuota(*ptrPila)) {
		printf("\n\tLa pila e' vuota!\n");//Se � vuota messaggio di errore
		return;
	}
	if (ptrPila->iUltimo == (ptrPila->size - 1) / 2 && ptrPila->size != 1) { //Se ne sono stati cancellati la met� restringe il vettore
		ptrPila->size /= 2; //Dimezza la dimensione
		ptrPila->first = (ElementPila*)realloc(ptrPila->first, ptrPila->size * sizeof(ElementPila)); //Riassegna al ptr al primo elemento la nuova locazione
		if (ptrPila->first == NULL) {
			printf("\n\tMemoria insufficiente!\n"); //In caso di errore nella malloc
			return;
		}
	}
	*ptrElem = ptrPila->first[ptrPila->iUltimo]; //Assegna al parametro in uscita il valore
	ptrPila->first[ptrPila->iUltimo] = NULL; //Assegna NULL all'ultimo elemento
	ptrPila->iUltimo--;//Decrementa l'indice
	return;
}

void Top(Pila p, ElementPila* ptrElem) {
	if (PilaVuota(p)) {
		printf("\n\tLa pila e' vuota!\n");//Se � vuota messaggio di errore
		return;
	}
	printf("\n\tL'elemento affiorante e': %d\n", *ptrElem); //Print dell'elemento affiorante
	*ptrElem = p.first[p.iUltimo]; //Assegna al parametro in uscita il valore
	return;
}

void StampaPila(Pila p) {
	if (PilaVuota(p)) { //In caso di pila vuota non viene stampato nulla
		return;
	}
	for (int i = 0; i <= p.iUltimo; i++) {
		printf("%d", *(p.first + i));
		if (i == p.iUltimo)
			break;
		printf(" --> ");
	}
	return;
}