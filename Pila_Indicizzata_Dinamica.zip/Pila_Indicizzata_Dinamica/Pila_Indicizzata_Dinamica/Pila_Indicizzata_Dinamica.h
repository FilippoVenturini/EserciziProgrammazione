//Author: Filippo Venturini
//Date(DeadLine): 20191229
//Notes: Esercizio 2 | Pila | Header
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#define EMPTY -1 //Pila vuota

typedef int ElementPila;

typedef struct {
	ElementPila* first;
	int iUltimo; //Mantiene l'indice dell'ultimo elemento
	int size; //Dimensione del vettore dinamico
}Pila;

void InizializzaPila(Pila*);
void LiberaPila(Pila*);
bool PilaPiena(Pila);
bool PilaVuota(Pila);
void Push(Pila*, ElementPila);
void Pop(Pila*, ElementPila*);
void Top(Pila, ElementPila*);
void StampaPila(Pila);