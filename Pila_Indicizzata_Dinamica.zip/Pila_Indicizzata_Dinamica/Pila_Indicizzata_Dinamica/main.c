//Author: Filippo Venturini
//Date(DeadLine): 20191229
//Notes: Esercizio 2 | Pila | main
#include "Pila_Indicizzata_Dinamica.h"
int main() {
	Pila p; //Crea una istanza
	InizializzaPila(&p); //Inizializza l'istanza
	ElementPila e = 0;
	int opzScelta;
	int verificaScanf;
	do {
		do {
			verificaScanf = 0;
			opzScelta = 0;
			printf("\n1) Push(Inserire).");
			printf("\n2) Pop(Rimuovere).");
			printf("\n3) Top(Visualizzare l'affiorante).");
			printf("\n4) Uscire.");
			printf("\nSelezionare l'opzione desiderata:");
			verificaScanf = scanf("%d", &opzScelta);
			while ((getchar()) != '\n'); //Pulizia del buffer
		} while (verificaScanf != 1 || opzScelta < 1 || opzScelta > 4);
		switch (opzScelta) {
		case 1:
			do {
				verificaScanf = 0;
				printf("\n\tInserire il valore: ");
				verificaScanf = scanf("%d", &e);
				while ((getchar()) != '\n'); //Pulizia del buffer
			} while (verificaScanf != 1);
			Push(&p, e);
			StampaPila(p);
			break;
		case 2:
			Pop(&p, &e);
			StampaPila(p);
			break;
		case 3:
			Top(p, &e);
			StampaPila(p);
			break;
		case 4:
			LiberaPila(&p);
			break;
		}
	} while (opzScelta != 4);
	getchar();
	return 0;
}