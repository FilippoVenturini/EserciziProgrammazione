//Author: Filippo Venturini
//Date(DeadLine): 20191229
//Notes: Esercizio 2 | Pila
#include "Pila_Indicizzata_Statica.h"

//Inizializza tutti i valori della pila a NULL e l'indice a -1
void InizializzaPila(Pila* ptrPila) {
	ptrPila->iUltimo = EMPTY;
	for (int i = 0; i < MAX; i++) {
		ptrPila->pila[i] = NULL;
	}
	return;
}

//Verifica che la lista sia piena controllando l'indice dell'ultimo elemento
bool PilaPiena(Pila p) {
	if (p.iUltimo == MAX - 1)
		return true;
	return false;
}

//Verifica se la lista � vuota
bool PilaVuota(Pila p) {
	if (p.iUltimo == EMPTY)
		return true;
	return false;
}

void Top(Pila* ptrPila, ElementPila* ptrElem) {
	if (PilaVuota(*ptrPila)) {
		printf("\n\tLa pila e' vuota!\n");//Se � vuota messaggio di errore
		return;
	}
	*ptrElem = ptrPila->pila[ptrPila->iUltimo]; //Memorizza l'elemento da restituire
	printf("\n\tL'elemento affiorante e': %d\n", *ptrElem); //Print dell'elemento affiorante
	return;
}

void Push(Pila* ptrPila, ElementPila value) {
	if (PilaPiena(*ptrPila)) {
		printf("\n\tLa pila e' piena!\n"); //Se � piena messaggio di errore
		return;
	}

	if (PilaVuota(*ptrPila)) { //Se la pila � vuota
		ptrPila->pila[0] = value; //Viene aggiunto come primo elemento
		ptrPila->iUltimo = 0; //E settato a 0 la posizione dell'ultimo
		return;
	}

	ptrPila->pila[(ptrPila->iUltimo) + 1] = value; //Aggiunge in coda alla pila l'elemento
	ptrPila->iUltimo++; //Aggiorna la posizione dell'ultimo
	return;
}

void Pop(Pila* ptrPila, ElementPila* ptrElem) {
	if (PilaVuota(*ptrPila)) {
		printf("\n\tLa pila e' vuota!\n");//Se � vuota messaggio di errore
		return;
	}
	*ptrElem = ptrPila->pila[ptrPila->iUltimo]; //Memorizza l'elemento da restituire
	printf("\n\tL'elemento rimosso e': %d\n", *ptrElem); //Print dell'elemento rimosso
	ptrPila->pila[ptrPila->iUltimo] = NULL; //Assegna NULL all'ultimo elemento
	ptrPila->iUltimo--;//Decrementa l'indice
	return;
}

void StampaPila(Pila p) {
	for (int i = 0; i <= p.iUltimo; i++) {
		printf("%d", p.pila[i]);
		if (i == p.iUltimo)
			break;
		printf(" --> ");
	}
	return;
}