//Author: Filippo Venturini
//Date(DeadLine): 20191229
//Notes: Esercizio 2 | Pila |
#include "Pila_Strutture.h"

//Inizializza tutti i valori della pila a NULL e l'indice a -1
void InizializzaPila(Pila* ptrPila) {
	*ptrPila = NULL; //Inizializza il ptr al primo elemento a NULL
	return;
}

//Verifica se la pila � vuota
bool PilaVuota(Pila p) {
	if (p == NULL)
		return true;
	return false;
}

void LiberaPila(Pila* ptrPila) {
	if (PilaVuota(*ptrPila)) {
		return; //Se la pila � vuota esce
	}
	NodoPila* tmp = *ptrPila;
	while (tmp->next != NULL) {
		tmp = tmp->next; //Scorre tmp
		free(*ptrPila); //Cancella l'elemento precedente
		*ptrPila = tmp; //Scorre il ptr al precedente
	}
	free(tmp); //Cancella l'ultimo elemento
	return;
}

void Push(Pila* ptrPila, ElementPila value) {
	if (PilaVuota(*ptrPila)) { //Se la pila � vuota
		*ptrPila = (Pila)malloc(sizeof(NodoPila)); //Viene assegnato al puntatore alla testa lo spazio necessario ad un nodo
		if (*ptrPila == NULL) {
			printf("\n\tMemoria insufficente!\n"); //Controllo per la malloc
			return;
		}
		(*ptrPila)->value = value; //Assegna il valore all'attributo del NodoPila
		(*ptrPila)->next = NULL; //Assegna NULL al puntatore all'elemento successivo
		return;
	}

	Pila tmp = *ptrPila; //Puntatore temporaneo al primo elemento
	while (tmp->next != NULL) { //Finch� non arriva all'ultimo
		tmp = tmp->next; //Scorre la lista
	}

	Pila tmp2 = (Pila)malloc(sizeof(NodoPila)); //Alloca lo spazio per il nuovo nodo
	if (tmp2 == NULL) {
		printf("\n\tMemoria insufficente!\n"); //Controllo per la malloc
		return;
	}
	tmp2->next = NULL;
	tmp2->value = value; //Assegna il valore
	tmp->next = tmp2; //Collega il nuovo nodo al precedente
	return;
}

void Pop(Pila* ptrPila, ElementPila*ptrElem) {
	if (PilaVuota(*ptrPila)) {
		printf("\n\tLa pila e' vuota!\n");//Se � vuota messaggio di errore
		return;
	}

	if ((*ptrPila)->next == NULL) { //Se viene invocata la funzione Pop con un solo elemento
		*ptrElem = (*ptrPila)->value; //Restituisce il valore dell'elemento
		free(*ptrPila); //Cancella l'elemento
		*ptrPila = NULL; //Fa puntare a NULL il puntatore al primo elemento
		return;
	}

	NodoPila* tmp = *ptrPila;
	NodoPila* tmp1 = (*ptrPila)->next; //Tmp di una posizione avanti
	while (tmp1->next != NULL) { //Scorre fino alla fine
		tmp = tmp->next;
		tmp1 = tmp1->next;
	}
	*ptrElem = tmp->value; //Restituisce il valore dell'elemento
	free(tmp1); //Cancella l'elemento pi� avanti
	tmp->next = NULL; //Setta a NULL il next dell'ultimo
	return;
}

void Top(Pila p, ElementPila* ptrElem) {
	if (PilaVuota(p)) {
		printf("\n\tLa pila e' vuota!\n");//Se � vuota messaggio di errore
		return;
	}
	if (p->next == NULL) { //Se viene invocata la funzione Top con un solo elemento
		*ptrElem = p->value; //Restituisce il valore dell'elemento
		printf("\n\tL'elemento affiorante e': %d\n", *ptrElem); //Print dell'elemento affiorante
		return;
	}
	NodoPila* tmp = p;
	NodoPila* tmp1 = p->next; //Tmp di una posizione avanti
	while (tmp1->next != NULL) { //Scorre fino alla fine
		tmp = tmp->next;
		tmp1 = tmp1->next;
	}
	*ptrElem = tmp1->value; //Restituisce il valore dell'elemento
	printf("\n\tL'elemento affiorante e': %d\n", *ptrElem); //Print dell'elemento affiorante
	return;
}
void StampaPila(Pila p) {
	while (p != NULL) {
		printf("%d", p->value);
		if (p->next == NULL)
			break;
		printf(" --> ");
		p = p->next; //Scorre la lista
	}
	return;
}