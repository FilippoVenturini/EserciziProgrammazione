//Author: Filippo Venturini
//Date(DeadLine): 20191229
//Notes: Esercizio 2 | Pila | Header
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

typedef int ElementPila; //Definisce il tipo int come il tipo dell'elemento della pila

typedef struct {
	ElementPila value;
	struct NodoPila* next;
} NodoPila; //Un nodo della pila contiene il valore e il puntatore al successivo

typedef NodoPila* Pila; //La pila � il puntatore alla testa

void InizializzaPila(Pila*);
void LiberaPila(Pila*);
bool PilaVuota(Pila);
void Push(Pila*, ElementPila);
void Pop(Pila*, ElementPila*);
void Top(Pila, ElementPila*);
void StampaPila(Pila);